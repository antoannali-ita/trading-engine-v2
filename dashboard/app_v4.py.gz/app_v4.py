from __future__ import annotations

import os
from datetime import datetime

import pandas as pd
import streamlit as st

try:
    from dashboard.data_access import (
        ai_analysis,
        engine_health,
        latest_confluence,
        manual_requests,
        notifications,
        performance,
        performance_summary,
        request_run,
        runs,
        signals,
        utc_label,
    )
except ModuleNotFoundError:
    from data_access import (
        ai_analysis,
        engine_health,
        latest_confluence,
        manual_requests,
        notifications,
        performance,
        performance_summary,
        request_run,
        runs,
        signals,
        utc_label,
    )

st.set_page_config(page_title="Trading Engine Control Center", page_icon="📈", layout="wide")

st.markdown(
    """
    <style>
    .block-container {padding-top: 1.25rem; padding-bottom: 2rem;}
    .hero {padding: 1rem 1.2rem; border: 1px solid rgba(128,128,128,.22); border-radius: 16px; margin-bottom: .8rem;}
    .hero h1 {margin: 0 0 .2rem 0; font-size: 2.1rem;}
    .muted {opacity: .72; font-size: .92rem;}
    .ux-card {border: 1px solid rgba(128,128,128,.24); border-radius: 14px; padding: 14px 16px; min-height: 112px; transition: .18s ease; background: rgba(128,128,128,.035);}
    .ux-card:hover {transform: translateY(-2px); border-color: rgba(80,130,255,.65); box-shadow: 0 7px 24px rgba(0,0,0,.08);}
    .ux-card .icon {font-size: 1.65rem;}
    .ux-card .title {font-weight: 700; margin-top: 4px;}
    .ux-card .desc {opacity: .72; font-size: .86rem; margin-top: 6px;}
    .flow {display:flex; align-items:center; gap:8px; flex-wrap:wrap; margin: 12px 0 18px 0;}
    .node {border:1px solid rgba(128,128,128,.30); border-radius:14px; padding:12px 14px; min-width:150px; text-align:center; background:rgba(128,128,128,.04); transition:.18s ease; cursor:help;}
    .node:hover {transform:scale(1.025); border-color:rgba(80,130,255,.70); box-shadow:0 5px 18px rgba(0,0,0,.08);}
    .arrow {opacity:.55; font-size:1.35rem;}
    .search-hit {border-left:4px solid rgba(80,130,255,.75); background:rgba(80,130,255,.06); border-radius:8px; padding:.65rem .85rem; margin:.45rem 0;}
    </style>
    """,
    unsafe_allow_html=True,
)

HELP = {
    "engine_id": "Motore che ha prodotto il run o il segnale.",
    "strategy": "Strategia applicata dal motore.",
    "market": "Mercato di riferimento, per esempio USA o ITALY.",
    "horizon": "Orizzonte temporale principale.",
    "stato": "Stato sintetico del motore.",
    "computed_health": "HEALTHY regolare; RUNNING in esecuzione; STALE non aggiornato; FAILED ultimo run fallito.",
    "last_started_at": "Ora di avvio dell'ultimo run.",
    "last_finished_at": "Ora di completamento dell'ultimo run.",
    "signals_found": "Numero di segnali prodotti dal run.",
    "detected_at": "Momento in cui il segnale è stato registrato.",
    "ticker": "Simbolo del titolo analizzato.",
    "engine": "Famiglia del motore che ha generato il segnale.",
    "signal_type": "Tipo di segnale o livello di confluenza.",
    "decision": "Decisione normalizzata del motore/orchestratore.",
    "conviction": "Forza sintetica. Va letta insieme alla confluenza.",
    "is_actionable": "True: il segnale supera i gate minimi per avanzare.",
    "price": "Prezzo osservato al momento del segnale.",
    "entry": "Livello di ingresso proposto.",
    "stop": "Livello di protezione previsto.",
    "tp1": "Primo obiettivo di profitto.",
    "tp2": "Secondo obiettivo di profitto.",
    "status": "Stato del processo o dell'analisi.",
    "alignment": "TradingAgents: CONFIRM, NEUTRAL, CAUTION o VETO.",
    "confidence": "Confidenza dichiarata dall'AI, se disponibile.",
    "verdict": "Verdetto sintetico TradingAgents.",
    "summary": "Sintesi testuale dell'analisi AI.",
    "trigger_reason": "Perché l'Orchestrator ha chiamato TradingAgents.",
    "started_at": "Ora di avvio.",
    "finished_at": "Ora di fine.",
    "trigger_source": "Origine: schedule, manuale, web o orchestrazione.",
    "duration_seconds": "Durata del run in secondi.",
    "records_processed": "Record elaborati dal motore.",
    "error_message": "Dettaglio dell'errore, se presente.",
    "requested_at": "Quando è stata inserita la richiesta manuale.",
    "requested_by": "Chi ha richiesto l'esecuzione.",
    "github_run_id": "ID del run GitHub Actions.",
    "run_id": "Identificativo applicativo del run.",
    "completed_at": "Quando il processo si è concluso.",
    "outcome": "Orizzonte di performance, es. MARK_5D.",
    "entry_price": "Prezzo iniziale usato per la misurazione.",
    "exit_price": "Prezzo rilevato alla fine dell'orizzonte.",
    "pnl_pct": "Variazione percentuale ingresso/uscita.",
    "max_drawdown_pct": "Peggior drawdown peak-to-trough nella finestra.",
    "max_favorable_excursion_pct": "Massimo movimento favorevole.",
    "holding_minutes": "Durata teorica della finestra.",
    "attempted_at": "Momento del tentativo di notifica.",
    "sent_at": "Momento dell'invio effettivo.",
    "event_type": "Tipo di evento notificato.",
    "channel": "Canale usato: EMAIL, WHATSAPP, ecc.",
    "provider": "Servizio tecnico usato per l'invio.",
}

GUIDE_TOPICS = [
    ("Home", "Stato generale", "Controlla prima salute motori, confluenze recenti e anomalie. È la pagina da aprire per capire in pochi secondi se il sistema sta lavorando.", "home motori healthy actionable stato"),
    ("Produzione", "Decision Board", "Vista operativa principale: unisce confluence dei motori e giudizio TradingAgents. Parti da is_actionable, poi signal_type/conviction e infine AI alignment.", "decisioni confluence actionable tradingagents confirm veto"),
    ("Produzione", "Motori", "Mostra salute, mercato, orizzonte, ultimo run, durata e segnali trovati. STALE o FAILED richiedono verifica.", "motori scheduler health stale failed run"),
    ("Produzione", "Segnali", "Dato normalizzato prodotto dai motori. Entry/stop/tp descrivono il setup; conviction indica forza; actionable decide se può avanzare.", "segnali entry stop tp conviction actionable"),
    ("Produzione", "TradingAgents", "Seconda opinione AI, non motore primario. CONFIRM rafforza, NEUTRAL non cambia, CAUTION invita prudenza, VETO segnala incompatibilità o rischio.", "ai tradingagents confirm neutral caution veto"),
    ("Produzione", "Performance", "Misura cosa è successo dopo i segnali e serve a valutare la strategia nel tempo, non il singolo trade.", "performance pnl drawdown mfe strategie"),
    ("Laboratorio", "Control Room", "Area sperimentale separata dalla produzione: opportunity feed, paper trading, research, backtest ed evolution.", "laboratorio lab paper research backtest evolution"),
    ("Operations", "Run & Log", "Ogni riga è un'esecuzione. Parti da status; se FAILED leggi error_message; poi durata, records_processed e signals_found.", "run log error failed duration records"),
    ("Operations", "Esegui ora", "Crea una manual_run_request in Supabase. L'Orchestrator la prende in carico senza esporre token GitHub al browser.", "manuale esegui ora requested dispatched running success"),
    ("Operations", "Notifiche", "Controlla invio e deduplica: SENT inviata, FAILED fallita, SKIPPED volutamente saltata.", "notifiche email whatsapp sent failed skipped dedup"),
    ("Architettura", "Flusso end-to-end", "CORE/FAST -> Supabase -> Orchestrator -> Multi-Horizon -> TradingAgents se qualificato -> decisione finale -> notifica -> performance.", "architettura core fast supabase orchestrator multihorizon tradingagents"),
    ("Scheduler", "Quando gira", "FAST frequente nei feriali; CORE giornaliero per mercato; Orchestrator ogni 15 minuti; performance giornaliera; Lab paper giornaliero e research/evolution settimanali.", "scheduler orari cron ogni 15 minuti fast core performance lab"),
    ("Glossario", "Confluenza", "SINGLE_SIGNAL = un motore base positivo; DOUBLE_CONFIRMATION = due famiglie base; TRIPLE_CONFIRMATION = tre. Multi-Horizon è validazione indipendente e non un duplicato.", "single double triple confirmation confluenza multihorizon"),
]

ARCH_PDF_URL = "https://github.com/antoannali-ita/trading-engine-v2/blob/main/docs/Trading_Engine_Guida_Architettura_2026-08-21.pdf"


def require_access() -> None:
    expected = (os.getenv("DASHBOARD_PASSWORD") or "").strip()
    if not expected:
        return
    if st.session_state.get("dashboard_auth"):
        return
    st.title("🔐 Trading Engine Control Center")
    pwd = st.text_input("Password", type="password")
    if st.button("Accedi", type="primary"):
        if pwd == expected:
            st.session_state["dashboard_auth"] = True
            st.rerun()
        st.error("Password non valida")
    st.stop()


def as_df(rows: list[dict]) -> pd.DataFrame:
    return pd.DataFrame(rows) if rows else pd.DataFrame()


def badge(value: str | None) -> str:
    v = str(value or "UNKNOWN").upper()
    icon = {
        "HEALTHY": "🟢", "SUCCESS": "🟢", "SENT": "🟢", "CONFIRM": "🟢",
        "RUNNING": "🔵", "PENDING": "🟡", "REQUESTED": "🟡", "DISPATCHED": "🔵",
        "DEGRADED": "🟠", "CAUTION": "🟠", "NEUTRAL": "⚪", "STALE": "🟠",
        "FAILED": "🔴", "VETO": "🔴", "DISABLED": "⚫", "UNKNOWN": "⚪",
    }.get(v, "⚪")
    return f"{icon} {v}"


def column_config(cols) -> dict:
    return {c: st.column_config.TextColumn(c, help=HELP[c]) for c in cols if c in HELP}


def explain(title: str, body: str, bullets: list[str] | None = None) -> None:
    with st.expander(f"ℹ️ Come leggere: {title}", expanded=False):
        st.write(body)
        for item in bullets or []:
            st.markdown(f"- {item}")


def show_table(df: pd.DataFrame, cols: list[str], limit: int = 300) -> None:
    cols = [c for c in cols if c in df.columns]
    if not cols:
        st.info("Nessuna colonna disponibile per questa vista.")
        return
    st.dataframe(df[cols].head(limit), use_container_width=True, hide_index=True, column_config=column_config(cols))


def visual_cards(cards: list[tuple[str, str, str]]) -> None:
    columns = st.columns(len(cards))
    for col, (icon, title, desc) in zip(columns, cards):
        with col:
            st.markdown(f'<div class="ux-card" title="{desc}"><div class="icon">{icon}</div><div class="title">{title}</div><div class="desc">{desc}</div></div>', unsafe_allow_html=True)


@st.cache_data(ttl=30, show_spinner=False)
def load_snapshot() -> dict:
    return {
        "health": engine_health(),
        "signals": signals(1200),
        "confluence": latest_confluence(300),
        "runs": runs(600),
        "ai": ai_analysis(400),
        "notifications": notifications(600),
        "performance": performance(1200),
        "performance_summary": performance_summary(),
        "requests": manual_requests(250),
        "loaded_at": datetime.now().isoformat(timespec="seconds"),
    }


def decision_board(conf_df: pd.DataFrame, ai_df: pd.DataFrame) -> pd.DataFrame:
    if conf_df.empty:
        return pd.DataFrame()
    view = conf_df.copy()
    if not ai_df.empty and {"ticker", "market"}.issubset(ai_df.columns):
        ai = ai_df.copy()
        ai = ai.sort_values("started_at", ascending=False) if "started_at" in ai.columns else ai
        ai = ai.drop_duplicates(subset=["market", "ticker"], keep="first")
        keep = [c for c in ["market", "ticker", "status", "alignment", "confidence", "verdict", "summary", "completed_at"] if c in ai.columns]
        ai = ai[keep].rename(columns={"status": "ai_status", "alignment": "ai_alignment", "confidence": "ai_confidence", "verdict": "ai_verdict", "summary": "ai_summary", "completed_at": "ai_completed_at"})
        view = view.merge(ai, on=["market", "ticker"], how="left")
    return view


def architecture_block() -> None:
    st.markdown(
        """
        <div class="flow">
          <div class="node" title="Motore medio periodo: seleziona opportunità e persiste segnali.">🧭<br><b>CORE</b><br><small>3-6M</small></div>
          <div class="arrow">→</div>
          <div class="node" title="Supabase conserva segnali, run, AI, eventi, notifiche, richieste manuali e performance.">🗄️<br><b>Supabase</b><br><small>memoria centrale</small></div>
          <div class="arrow">→</div>
          <div class="node" title="Unisce i segnali, applica confluence, deduplica e decide i dispatch successivi.">🧠<br><b>Orchestrator</b><br><small>coordina</small></div>
          <div class="arrow">→</div>
          <div class="node" title="Valida il titolo su più orizzonti indipendenti.">🔭<br><b>Multi-Horizon</b><br><small>validazione</small></div>
          <div class="arrow">→</div>
          <div class="node" title="Seconda opinione AI, chiamata solo su segnali qualificati.">🤖<br><b>TradingAgents</b><br><small>second opinion</small></div>
          <div class="arrow">→</div>
          <div class="node" title="Decisione finale deduplicata sui canali configurati.">🔔<br><b>Alert finali</b></div>
        </div>
        <div class="flow">
          <div class="node" title="FAST controlla condizioni operative e vicinanza alle zone di ingresso.">⚡<br><b>FAST</b><br><small>monitor operativo</small></div>
          <div class="arrow">→</div>
          <div class="node" title="GitHub Actions esegue workflow pianificati e manuali.">⚙️<br><b>GitHub Actions</b></div>
          <div class="arrow">→</div>
          <div class="node" title="La dashboard legge Supabase e inserisce richieste manuali senza esporre token GitHub.">🖥️<br><b>Dashboard</b></div>
          <div class="arrow">↔</div>
          <div class="node" title="Paper, ricerca, backtest ed evoluzione separati dalla produzione.">🧪<br><b>Laboratory</b></div>
        </div>
        """,
        unsafe_allow_html=True,
    )
    st.markdown("**Sequenza tipica:** CORE/FAST → Supabase → Confluence → Multi-Horizon → TradingAgents se qualificato → decisione finale → notifica → performance.")


require_access()

head_l, head_r = st.columns([5, 1])
with head_l:
    st.markdown('<div class="hero"><h1>📈 Trading Engine Control Center</h1><div class="muted">Produzione, Laboratory e Operations separati; tutta la documentazione è raccolta nella Guida.</div></div>', unsafe_allow_html=True)
with head_r:
    if st.button("↻ Aggiorna dati", use_container_width=True, help="Svuota la cache e rilegge Supabase."):
        st.cache_data.clear()
        st.rerun()

try:
    snap = load_snapshot()
except Exception as exc:
    st.error(f"Connessione dati non disponibile: {type(exc).__name__}: {exc}")
    st.stop()

health_rows = snap["health"]
sig_rows = snap["signals"]
conf_rows = snap["confluence"]
run_rows = snap["runs"]
ai_rows = snap["ai"]
notif_rows = snap["notifications"]
perf_rows = snap["performance"]
perf_summary_rows = snap["performance_summary"]
request_rows = snap["requests"]

health_df = as_df(health_rows)
sig_df = as_df(sig_rows)
conf_df = as_df(conf_rows)
run_df = as_df(run_rows)
ai_df = as_df(ai_rows)
notif_df = as_df(notif_rows)
perf_df = as_df(perf_rows)
perf_summary_df = as_df(perf_summary_rows)
request_df = as_df(request_rows)
decision_df = decision_board(conf_df, ai_df)

healthy = sum(str(r.get("computed_health") or r.get("registry_status") or "").upper() == "HEALTHY" for r in health_rows)
failed = sum(str(r.get("computed_health") or r.get("registry_status") or "").upper() in {"FAILED", "STALE", "DEGRADED"} for r in health_rows)
actionable = sum(bool(r.get("is_actionable")) for r in conf_rows)
ai_pending = sum(str(r.get("status") or "").upper() in {"PENDING", "RUNNING"} for r in ai_rows)
manual_active = sum(str(r.get("status") or "").upper() in {"REQUESTED", "DISPATCHED", "RUNNING"} for r in request_rows)

k1, k2, k3, k4, k5 = st.columns(5)
k1.metric("🟢 Motori healthy", f"{healthy}/{len(health_rows)}", help="Motori il cui ultimo stato risulta regolare.")
k2.metric("🟠 Da verificare", failed, help="Motori FAILED, STALE o DEGRADED.")
k3.metric("🎯 Actionable", actionable, help="Confluenze che hanno superato i gate minimi.")
k4.metric("🧠 AI attive", ai_pending, help="TradingAgents PENDING o RUNNING.")
k5.metric("▶️ Manuali attive", manual_active, help="Richieste manuali non concluse.")

main_tabs = st.tabs(["🏠 Home", "🏭 Produzione", "🧪 Laboratorio", "🛠️ Operations", "📚 Guida"])

with main_tabs[0]:
    st.subheader("Control Center")
    visual_cards([
        ("🏭", "Produzione", "CORE, FAST, Multi-Horizon, TradingAgents e decisioni operative."),
        ("🧪", "Laboratorio", "Ricerca, paper trading, backtest ed evoluzione, separati dalla produzione."),
        ("🛠️", "Operations", "Run, log, richieste manuali e notifiche."),
        ("📚", "Guida", "Ricerca, struttura, glossario, scheduler, architettura e PDF."),
    ])
    st.markdown("### Stato motori")
    explain("Stato motori", "La vista più veloce per capire se l'infrastruttura sta lavorando regolarmente.")
    if health_df.empty:
        st.info("Registry vuoto.")
    else:
        view = health_df.copy()
        status_col = "computed_health" if "computed_health" in view.columns else "registry_status"
        view["stato"] = view[status_col].map(badge)
        for col in ["last_started_at", "last_finished_at", "last_run_at", "next_expected_run_at"]:
            if col in view.columns:
                view[col] = view[col].map(utc_label)
        show_table(view, ["engine_id", "strategy", "market", "horizon", "stato", "last_started_at", "last_finished_at", "signals_found"], 100)

with main_tabs[1]:
    prod_tabs = st.tabs(["🎯 Decisioni", "⚙️ Motori", "📡 Segnali", "🧠 TradingAgents", "📈 Performance"])
    with prod_tabs[0]:
        st.subheader("Decision Board")
        explain("Decision Board", "È la pagina operativa principale. Leggi prima actionable, poi il livello di confluenza e infine TradingAgents.")
        if decision_df.empty:
            st.info("Nessuna decisione aggregata disponibile.")
        else:
            only_action = st.checkbox("Solo decisioni actionable", value=True)
            view = decision_df.copy()
            if only_action and "is_actionable" in view.columns:
                view = view[view["is_actionable"] == True]
            if "ai_alignment" in view.columns:
                view["AI"] = view["ai_alignment"].map(badge)
            show_table(view, ["detected_at", "market", "ticker", "signal_type", "conviction", "is_actionable", "AI", "ai_confidence", "ai_verdict", "ai_summary"], 120)

    with prod_tabs[1]:
        st.subheader("Motori e scheduler")
        explain("Motori", "HEALTHY regolare; STALE non aggiornato; FAILED ultimo run fallito. Controlla poi durata e signals_found.")
        if health_df.empty:
            st.info("Registry vuoto.")
        else:
            view = health_df.copy()
            status_col = "computed_health" if "computed_health" in view.columns else "registry_status"
            view[status_col] = view[status_col].map(badge)
            for col in ["last_run_at", "last_started_at", "last_finished_at", "next_expected_run_at"]:
                if col in view.columns:
                    view[col] = view[col].map(utc_label)
            st.dataframe(view, use_container_width=True, hide_index=True, column_config=column_config(view.columns))

    with prod_tabs[2]:
        st.subheader("Segnali di produzione")
        explain("Segnali", "Entry/stop/tp sono livelli del setup; conviction indica forza; actionable stabilisce se il segnale può avanzare.")
        if sig_df.empty:
            st.info("Nessun segnale registrato.")
        else:
            filters = st.columns(4)
            markets = ["TUTTI"] + sorted(sig_df["market"].dropna().astype(str).unique().tolist()) if "market" in sig_df.columns else ["TUTTI"]
            engines = ["TUTTI"] + sorted(sig_df["engine"].dropna().astype(str).unique().tolist()) if "engine" in sig_df.columns else ["TUTTI"]
            market = filters[0].selectbox("Mercato", markets)
            engine = filters[1].selectbox("Motore", engines)
            ticker = filters[2].text_input("Ticker contiene").strip().upper()
            only_action = filters[3].checkbox("Solo actionable")
            view = sig_df.copy()
            if market != "TUTTI": view = view[view["market"].astype(str) == market]
            if engine != "TUTTI": view = view[view["engine"].astype(str) == engine]
            if ticker and "ticker" in view.columns: view = view[view["ticker"].astype(str).str.upper().str.contains(ticker, regex=False)]
            if only_action and "is_actionable" in view.columns: view = view[view["is_actionable"] == True]
            show_table(view, ["detected_at", "market", "ticker", "engine", "strategy", "signal_type", "decision", "conviction", "price", "entry", "stop", "tp1", "tp2", "is_actionable"], 300)

    with prod_tabs[3]:
        st.subheader("TradingAgents")
        explain("TradingAgents", "Seconda opinione AI: CONFIRM rafforza, NEUTRAL non cambia, CAUTION invita prudenza, VETO segnala incompatibilità/rischio.")
        if ai_df.empty:
            st.info("Nessuna analisi AI registrata. È normale finché non scatta una confluenza qualificata.")
        else:
            show_table(ai_df, ["started_at", "completed_at", "market", "ticker", "status", "alignment", "confidence", "verdict", "summary", "trigger_reason", "entry", "stop", "tp1", "tp2", "error_message"], 200)

    with prod_tabs[4]:
        st.subheader("Performance")
        explain("Performance", "Valuta la strategia nel tempo. PnL% misura il rendimento; drawdown il peggior arretramento; MFE il massimo movimento favorevole.")
        if not perf_summary_df.empty:
            show_table(perf_summary_df, list(perf_summary_df.columns), 300)
        elif perf_df.empty:
            st.info("I dati compariranno dopo che i segnali avranno maturato un orizzonte misurabile.")
        if not perf_df.empty:
            show_table(perf_df, ["created_at", "engine_id", "strategy", "market", "ticker", "outcome", "entry_price", "exit_price", "pnl_pct", "max_drawdown_pct", "max_favorable_excursion_pct", "holding_minutes"], 400)

with main_tabs[2]:
    lab_tabs = st.tabs(["🧪 Control Room", "🧾 Paper / Portfolio", "🔬 Ricerca & Backtest", "🧬 Strategy Evolution"])
    lab_mask = pd.Series(False, index=run_df.index) if not run_df.empty else pd.Series(dtype=bool)
    if not run_df.empty:
        for c in ["engine_id", "strategy"]:
            if c in run_df.columns:
                lab_mask = lab_mask | run_df[c].fillna("").astype(str).str.upper().str.contains("LAB|PAPER|RESEARCH|EVOLUTION", regex=True)
    lab_runs = run_df[lab_mask].copy() if not run_df.empty else pd.DataFrame()
    with lab_tabs[0]:
        st.subheader("Laboratory Control Room")
        st.warning("Il Laboratory è separato dalla produzione: studia, simula e confronta senza cambiare i segnali live.")
        visual_cards([
            ("🧪", "Opportunity Feed", "Opportunità da studiare, non segnali live automatici."),
            ("🧾", "Paper Trading", "Simulazioni senza ordini reali."),
            ("🔬", "Research", "Backtest e analisi periodiche."),
            ("🧬", "Evolution", "Confronta varianti prima di qualunque promozione."),
        ])
        if lab_runs.empty:
            st.info("Nessun run Laboratory centralizzato ancora.")
        else:
            show_table(lab_runs, ["started_at", "finished_at", "engine_id", "strategy", "status", "records_processed", "signals_found", "error_message"], 100)
    with lab_tabs[1]:
        st.subheader("Paper / Portfolio")
        st.info("Lo schema centrale non espone ancora le vecchie tabelle paper-portfolio. La pagina resta separata per non confondere simulazioni e produzione.")
    with lab_tabs[2]:
        st.subheader("Ricerca & Backtest")
        if lab_runs.empty: st.info("Nessun risultato research centralizzato disponibile ancora.")
        else: show_table(lab_runs, list(lab_runs.columns), 150)
    with lab_tabs[3]:
        st.subheader("Strategy Evolution")
        st.info("Qui verranno mostrati baseline, delta KPI e decisioni PROMOTE/REJECT quando l'evolution worker pubblicherà risultati strutturati.")

with main_tabs[3]:
    ops_tabs = st.tabs(["📝 Run & Log", "▶️ Esegui ora", "🔔 Notifiche"])
    with ops_tabs[0]:
        st.subheader("Run & Log")
        explain("Run", "Parti da status; se FAILED guarda error_message; poi durata e signals_found.")
        if not run_df.empty:
            show_table(run_df, ["started_at", "finished_at", "engine_id", "market", "strategy", "trigger_source", "status", "duration_seconds", "records_processed", "signals_found", "error_message"], 300)
        st.markdown("### Richieste manuali")
        explain("Richieste manuali", "Percorso corretto: REQUESTED → DISPATCHED → RUNNING → SUCCESS.")
        if request_df.empty: st.info("Nessuna richiesta manuale ancora.")
        else: show_table(request_df, ["requested_at", "engine_id", "market", "strategy", "requested_by", "status", "github_run_id", "run_id", "completed_at", "error_message"], 200)
    with ops_tabs[1]:
        st.subheader("Esegui ora")
        st.warning("Crea una richiesta in Supabase; l'Orchestrator lancia il workflow senza esporre token GitHub al browser.")
        engines = [r for r in health_rows if str(r.get("engine_id") or "").upper() not in {"ORCHESTRATOR", "TRADINGAGENTS"}]
        labels = [f"{r.get('engine_id')} | {r.get('strategy')} | {r.get('market')}" for r in engines]
        selected = st.selectbox("Motore", labels) if labels else None
        requested_by = st.text_input("Richiesto da", value="Antonio")
        if st.button("▶️ ESEGUI ORA", type="primary", disabled=not selected):
            row = engines[labels.index(selected)]
            created = request_run(str(row.get("engine_id")), str(row.get("market")), str(row.get("strategy") or ""), send_email=True, send_whatsapp=False, requested_by=requested_by)
            st.cache_data.clear()
            st.success(f"Richiesta creata: {created.get('request_id', 'OK')} · stato REQUESTED")
    with ops_tabs[2]:
        st.subheader("Notifiche")
        explain("Notifiche", "SENT inviata, FAILED fallita, SKIPPED volutamente non inviata. Qui verifichi anche la deduplica.")
        if notif_df.empty: st.info("Nessuna notifica registrata.")
        else: show_table(notif_df, ["attempted_at", "sent_at", "ticker", "event_type", "channel", "status", "provider", "error_message"], 400)

with main_tabs[4]:
    st.subheader("Centro Guida")
    st.caption("Tutta la struttura e le spiegazioni sono qui. Cerca una parola come 'actionable', 'TradingAgents', 'FAILED', 'Multi-Horizon', 'scheduler' o 'stop'.")
    q = st.text_input("🔎 Cerca nella guida", placeholder="Es. come leggo actionable? oppure quando gira FAST?").strip().lower()
    if q:
        tokens = [t for t in q.split() if len(t) > 1]
        hits = []
        for area, title, body, tags in GUIDE_TOPICS:
            hay = f"{area} {title} {body} {tags}".lower()
            score = sum(t in hay for t in tokens)
            if score:
                hits.append((score, area, title, body))
        hits.sort(reverse=True)
        if not hits:
            st.info("Nessun risultato. Prova con un termine più breve o tecnico.")
        else:
            for _, area, title, body in hits[:12]:
                st.markdown(f'<div class="search-hit"><b>{area} · {title}</b><br>{body}</div>', unsafe_allow_html=True)

    guide_tabs = st.tabs(["🗺️ Struttura", "📖 Come usare", "🔤 Glossario", "⏱️ Scheduler", "🏗️ Architettura & PDF"])
    with guide_tabs[0]:
        visual_cards([
            ("🏠", "Home", "Stato generale e anomalie."),
            ("🏭", "Produzione", "Decisioni, motori, segnali, AI e performance."),
            ("🧪", "Laboratorio", "Paper, research, backtest ed evolution."),
            ("🛠️", "Operations", "Run, manuali e notifiche."),
            ("📚", "Guida", "Ricerca e documentazione completa."),
        ])
    with guide_tabs[1]:
        st.markdown("""
        1. **Home**: controlla prima lo stato dei motori.  
        2. **Produzione → Decisioni**: è la vista operativa principale.  
        3. **Produzione → Segnali**: entra nel dettaglio tecnico.  
        4. **TradingAgents**: leggi la seconda opinione solo quando attivata.  
        5. **Performance**: valuta le strategie nel tempo.  
        6. **Laboratorio**: considera tutto sperimentale.  
        7. **Operations**: usa Run & Log se qualcosa non gira.
        """)
        st.info("Sulle tabelle passa il mouse sul nome delle colonne: le principali hanno un tooltip. Ogni sezione ha anche un box ℹ️ Come leggere.")
    with guide_tabs[2]:
        for term, desc in [
            ("Actionable", "Ha superato i gate minimi per avanzare."),
            ("SINGLE_SIGNAL", "Un motore base positivo."),
            ("DOUBLE_CONFIRMATION", "Due famiglie base concordi."),
            ("TRIPLE_CONFIRMATION", "Tre famiglie base concordi."),
            ("Multi-Horizon", "Validazione indipendente; non duplica CORE/SHORT/FAST."),
            ("CONFIRM", "TradingAgents conferma."),
            ("CAUTION", "TradingAgents rileva elementi di prudenza."),
            ("VETO", "TradingAgents rileva incompatibilità/rischio forte."),
            ("STALE", "Motore non aggiornato entro la finestra attesa."),
        ]:
            st.markdown(f"**{term}** — {desc}")
    with guide_tabs[3]:
        st.markdown("""
        - **FAST**: controllo frequente nei feriali con gate sulla sessione.
        - **CORE Italia**: run giornaliero di fine sessione italiana.
        - **CORE USA**: run giornaliero secondo il cron del workflow.
        - **Orchestrator**: ogni 15 minuti.
        - **Performance worker**: una volta al giorno nei feriali.
        - **Laboratory paper feed**: giornaliero feriale.
        - **Research / Evolution**: settimanali.
        """)
        st.caption("La fonte autorevole resta il cron GitHub Actions, espresso in UTC.")
    with guide_tabs[4]:
        st.markdown("### Architettura logica")
        st.caption("Passa il mouse sui blocchi per la descrizione rapida.")
        architecture_block()
        st.link_button("📄 Apri il PDF: Guida e Architettura", ARCH_PDF_URL, use_container_width=False)
        st.caption("Il PDF riassume architettura, uso del sito, regole di lettura, scheduler e sicurezza.")

st.caption(f"Snapshot dati: {snap['loaded_at']} · Pagina: {datetime.now().isoformat(timespec='seconds')}")
